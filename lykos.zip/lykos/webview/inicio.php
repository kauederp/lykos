<?php

echo "
<div class='d-flex justify-content-center'>
    <img class='col-9' src='./modelo/1.png'>
</div>";
echo "
<div class='d-flex flex-column justify-content-center'>
    <h1 class='text-light text-center'>HELLO!</h1>
    <br/>
    <ul class='row' id='links-p-inicio'>
        <li class='btn '><a class='fs-1 text-decoration-none' href='?p=register'>REGISTER</a></li><br/>
        <h3 class='text-light fs-1 text-center' id='or'>or</h3>
        <li class='btn '><a class='fs-1 text-decoration-none' href='?p=login'>LOGIN</a></li>
    </ul>
</div>
";
